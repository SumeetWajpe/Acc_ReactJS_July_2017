 import React from 'react';

 export default  class UserAlbum extends React.Component{
    
        render(){

            var UsersToBeCreated = this.props.myusers.map((user,index)=>{
                return <div className="userDetails">
                    <h1 key={index}> {user.login} </h1> 
                        <img src={user.avatar_url} height="100px" width="100px" /><br/>
                     
                     <button onClick={this.props.incrementFollowers.bind(null,index)}
                      className="btn btn-primary">{user.followers}</button>
                     </div>
            });

            return (<div> 
                     <h1> User Album Component ! </h1>
                        <ul>
                            {UsersToBeCreated}
                        </ul>
                    </div>)
        }
    }

