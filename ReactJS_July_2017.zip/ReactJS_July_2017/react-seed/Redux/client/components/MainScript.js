
import {connect} from 'react-redux';
import {bindActionCreators} from 'redux';
import * as actions from '../actions/actionCreators';

import Main from './Main';

function mapStateToProps(storeData){
    return{
        myusers:storeData.users
    }
}

function mapDispatchToProps(dispatchObj){
    return bindActionCreators(actions,dispatchObj);
}

var App = connect(mapStateToProps,mapDispatchToProps)(Main);
export default App;