 import React from 'react';



 export default  class User extends React.Component{
    
        render(){
            return (<div> 
                     <h1> User Component ! </h1>
                        
                    </div>)
        }
    }

