export  function blogs(defData=[],action){
    
    switch(action.type){
        case 'ADD_BLOG':
        console.log('Inside Blogs Reducer..')
        return defData;
    default:
        return defData;
}
}