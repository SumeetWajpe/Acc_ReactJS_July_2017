
import {blogs} from './blogsReducer';
import {users} from './userReducer'; 
 
import {combineReducers} from 'redux';

var rootReducer = combineReducers({blogs,users});
export default rootReducer;