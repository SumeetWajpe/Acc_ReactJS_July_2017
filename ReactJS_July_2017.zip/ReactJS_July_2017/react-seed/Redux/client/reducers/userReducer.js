export function users(defData=[],action){
    
switch(action.type){
    case 'INCREMENT_FOLLOWERS':   
        console.log("The action : " + action.type);
        // to change the store data !
        var ind = action.index;
        console.log(defData);
        return [
            ...defData.slice(0,ind),
            {...defData[ind],followers:defData[ind].followers + 1},
            ...defData.slice(ind + 1)
        ];
    default:
        return defData;
}

    
}