export function incrementFollowers(index){
    return {
        type:'INCREMENT_FOLLOWERS',
        index
    }
}

export function addUser(){
 return {
        type:'ADD_USER'        
    }
}