import {createStore} from 'redux';

import rootReducer from './reducers/rootReducer';
// data

import users from './data/users';

// createStore(reducer,default store data)
var store = createStore(rootReducer,{users});

export default store;