import React from 'react';

export default class ButtonComponent extends React.Component{
    constructor(props){
        super(props);
        this.state = {count:this.props.InitialCount};
    }    
    onClickHandler(){               
                this.setState({count:this.state.count + 1});
    }     
    render(){
        return<div>
                <button className="btn btn-primary" onClick={this.onClickHandler.bind(this)} >
                    {this.state.count}</button>                    
             </div>
    }
}