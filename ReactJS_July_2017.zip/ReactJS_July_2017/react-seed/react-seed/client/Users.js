import React from 'react';

export default class UsersComponent extends React.Component{

    constructor(props){
       super(props);
       this.state =  {users:[]};
    }   
    componentDidMount(){
        $.get('https://api.github.com/users',(response)=>{
            //console.log(response);
            this.setState({users:response});
        });
    }

    render(){
        var usersToBcreated = this.state.users.map((user,index)=>{
            return <li key={index}>{user.login} </li>
        });
        return<div>
                <ul>
                    {usersToBcreated}
                </ul>
             </div>
    }
}